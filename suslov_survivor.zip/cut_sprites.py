#!/usr/bin/env python3
"""Вырезает маджента-фон из сгенерированного спрайта.

Использование:
    python3 cut_sprites.py вход.png выход.png [высота]

Убирает фон #FF00FF, обрезает по краю непрозрачного, при желании приводит
к заданной высоте с сохранением пропорций.
"""
import sys
from PIL import Image
import numpy as np


def cut(src, dst, target_h=None):
    im = Image.open(src).convert('RGBA')
    a = np.array(im).astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    # маджента = высокие R и B, заметно ниже G
    mask = (r > 110) & (b > 110) & (g < r - 55) & (g < b - 55)
    a[..., 3] = np.where(mask, 0, 255)
    im = Image.fromarray(a.astype('uint8'))
    bbox = im.getbbox()
    if bbox:
        im = im.crop(bbox)
    if target_h:
        w = max(1, round(im.width * target_h / im.height))
        im = im.resize((w, target_h), Image.LANCZOS)
    im.save(dst)
    print(f'{dst}  {im.width}x{im.height}')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    h = int(sys.argv[3]) if len(sys.argv) > 3 else None
    cut(sys.argv[1], sys.argv[2], h)
