#!/usr/bin/env python3
# Собирает автономную версию index.html со спрайтами, вшитыми как data:URI.
# Нужна только для того, чтобы игру можно было открыть по ссылке одним файлом.
# Рабочая версия игры — игра/index.html рядом с папкой sprites.

import base64, pathlib, re, sys

корень = pathlib.Path(__file__).parent / 'игра'
исходник = (корень / 'index.html').read_text(encoding='utf-8')

def в_дата_uri(путь: str) -> str:
    данные = (корень / путь).read_bytes()
    return 'data:image/png;base64,' + base64.b64encode(данные).decode('ascii')

def замена(совпадение):
    путь = совпадение.group(1)
    return "'" + в_дата_uri(путь) + "'"

результат = re.sub(r"'(sprites/[^']+\.png)'", замена, исходник)

вывод = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else (pathlib.Path(__file__).parent / 'превью.html')
вывод.write_text(результат, encoding='utf-8')
print(f'{вывод} — {len(результат)/1024:.0f} КБ')
